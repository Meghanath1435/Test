package com.luminous.pick;

import android.net.Uri;

public class CustomGallery {

	public String sdcardPath;
	public boolean isSeleted = false;
	public Uri sdCardUri;

}
